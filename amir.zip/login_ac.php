<?php
session_start();
include("header.php");
include("connec.php");
mysqli_set_charset($connect, "utf8mb4");

// گرفتن داده‌ها از فرم
$username = isset($_POST["username"]) ? $_POST["username"] : '';
$password = isset($_POST["password"]) ? $_POST["password"] : '';

// تابع نمایش پیام در مرکز صفحه
function showCenteredMessage($message, $color = 'red') {
    echo "
    <div class='flex items-center justify-center min-h-screen'>
        <div class='text-center text-{$color}-600 font-bold text-lg bg-{$color}-100 border border-{$color}-300 px-6 py-4 rounded-xl shadow-md'>
            $message
        </div>
    </div>
    ";
    include("footer.php");
    exit;
}

// بررسی ورودی‌ها
if (empty($username) || empty($password)) {
    showCenteredMessage("لطفاً نام کاربری و رمز عبور را وارد کنید.");
}

// بررسی کاربر با prepared statement
$query = "SELECT * FROM `user` WHERE `username` = ? AND `password` = ?";
$stmt = mysqli_prepare($connect, $query);

if (!$stmt) {
    die("خطا در آماده‌سازی دستور SQL: " . mysqli_error($connect));
}

mysqli_stmt_bind_param($stmt, "ss", $username, $password);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$user) {
    showCenteredMessage("نام کاربری یا رمز عبور اشتباه است.");
}

if ($user['type'] != 0) {
    showCenteredMessage("شما دسترسی به این بخش ندارید.");
}

// هدایت به پنل ادمین
header("Location: login_action.php");
exit;

include("footer.php");
?>
