<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>هنرستان دخترانه امیر کبیر</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Noto+Naskh+Arabic:wght@400;500;600;700&display=swap');
        
        body {
            font-family: 'Noto Naskh Arabic', serif;
            background-color: #f5f7fa;
        }
        
        .hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://images.unsplash.com/photo-1523050854058-8df90110c9f1?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
        }
        
        .course-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
        .event-card {
            transition: all 0.3s ease;
        }
        
        .event-card:hover {
            transform: scale(1.03);
        }
        
        .navbar {
            backdrop-filter: blur(10px);
        }
        
        .marquee {
            animation: marquee 15s linear infinite;
        }
        
        @keyframes marquee {
            0% { transform: translateX(0); }
            100% { transform: translateX(-50%); }
        }
        
        /* Custom spinner for loading */
        .spinner {
            width: 40px;
            height: 40px;
            border: 4px solid rgba(0, 0, 0, 0.1);
            border-left-color: #4f46e5;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar fixed top-0 w-full bg-purple-800 text-white shadow-lg z-50">
        <div class="container mx-auto px-4 py-3">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4 space-x-reverse">
                    <div class="flex items-center">
                        <i class="fas fa-school text-2xl text-purple-200"></i>
                        <a href="#" class="text-xl font-bold mr-2 hover:text-purple-200">هنرستان امیر کبیر</a>
                    </div>
                </div>
                
                <div class="hidden md:flex items-center space-x-6 space-x-reverse">
                    <a href="#home" class="hover:text-purple-200 transition">صفحه اصلی</a>
                    <a href="#about" class="hover:text-purple-200 transition">درباره ما</a>
                    <a href="#courses" class="hover:text-purple-200 transition">رشته‌ها</a>
                    <a href="#gallery" class="hover:text-purple-200 transition">گالری</a>
                    <a href="#contact" class="hover:text-purple-200 transition">تماس با ما</a>
                    <a href="login.php" class="hover:text-purple-200 transition"> مدیریت </a>
                </div>
                
                <button class="md:hidden text-white focus:outline-none" id="mobile-menu-button">
                    <i class="fas fa-bars text-2xl"></i>
                </button>
            </div>
        </div>
        
        <!-- Mobile menu -->
        <div class="hidden md:hidden bg-purple-700 w-full" id="mobile-menu">
            <div class="px-2 py-3 space-y-3 space-y-reverse">
                <a href="#home" class="block px-3 py-2 hover:bg-purple-600 rounded">صفحه اصلی</a>
                <a href="#about" class="block px-3 py-2 hover:bg-purple-600 rounded">درباره ما</a>
                <a href="#courses" class="block px-3 py-2 hover:bg-purple-600 rounded">رشته‌ها</a>
                <a href="#gallery" class="block px-3 py-2 hover:bg-purple-600 rounded">گالری</a>
                <a href="#contact" class="block px-3 py-2 hover:bg-purple-600 rounded">تماس با ما</a>
            </div>
        </div>
    </nav>
    <!-- Announcement Bar -->
    <div class="bg-yellow-400 text-purple-900 py-2 mt-16">
        <div class="container mx-auto px-4 overflow-hidden">
            <div class="marquee whitespace-nowrap">
                <span class="font-bold mx-4">ثبت نام سال تحصیلی جدید آغاز شد |</span>
                <span class="mx-4">تحوبل کارنامه های سال تحصیلی از اول تیر ماه |</span>
                <span class="mx-4">جلسه اولیاء و مربیان در روز چهارشنبه ساعت 16 برگزار می‌شود</span>
            </div>
        </div>
    </div>
<!-- Hero Section -->
<section class="hero-section text-white relative bg-cover bg-center bg-no-repeat" style="background-image: url('https://www.talab.org/wp-content/uploads/2023/05/1117966352-talab-org.jpg');">
  <!-- لایه مات‌کننده برای خوانایی متن -->
  <div class="absolute inset-0 bg-black bg-opacity-60"></div>

  <div class="container relative z-10 mx-auto px-6 py-24 flex flex-col items-center justify-center text-center">
    <h1 class="text-4xl md:text-6xl font-bold mb-6">هنرستان دخترانه امیرکبیر</h1>
    <p class="text-xl md:text-2xl mb-8 max-w-2xl">مرکزی برای پرورش استعدادهای فنی و مهارتی دانش‌آموزان دختر</p>
    <div class="flex flex-wrap justify-center gap-4">
      <a href="#courses" class="bg-white text-purple-800 font-bold py-3 px-6 rounded-full hover:bg-purple-100 transition duration-300">
        <i class="fas fa-graduation-cap ml-2"></i> مشاهده رشته‌ها
      </a>
      <a href="#contact" class="border-2 border-white text-white font-bold py-3 px-6 rounded-full hover:bg-white hover:text-purple-800 transition duration-300">
        <i class="fas fa-phone-alt ml-2"></i> ارتباط با ما
      </a>
    </div>
  </div>
</section>

 <!-- Stats Section -->
 <section class="bg-purple-100 py-12">
        <div class="container mx-auto px-6">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
                <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition">
                    <div class="text-purple-600 text-4xl mb-2">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <h3 class="text-3xl font-bold text-gray-800">500+</h3>
                    <p class="text-gray-600">دانش‌آموز</p>
                </div>
                <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition">
                    <div class="text-purple-600 text-4xl mb-2">
                        <i class="fas fa-chalkboard-teacher"></i>
                    </div>
                    <h3 class="text-3xl font-bold text-gray-800">35+</h3>
                    <p class="text-gray-600">استاد مجرب</p>
                </div>
                <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition">
                    <div class="text-purple-600 text-4xl mb-2">
                        <i class="fas fa-laptop-code"></i>
                    </div>
                    <h3 class="text-3xl font-bold text-gray-800">5</h3>
                    <p class="text-gray-600">رشته تحصیلی</p>
                </div>
                <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition">
                    <div class="text-purple-600 text-4xl mb-2">
                        <i class="fas fa-medal"></i>
                    </div>
                    <h3 class="text-3xl font-bold text-gray-800">12</h3>
                    <p class="text-gray-600">جایزه استانی</p>
                </div>
            </div>
        </div>
    </section>
    <!-- About Section -->
    <section id="about" class="py-16 bg-gray-50">
        <div class="container mx-auto px-4">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-purple-800 mb-4">درباره هنرستان امیر کبیر</h2>
                <div class="w-20 h-1 bg-purple-600 mx-auto"></div>
            </div>
            
           
            <div class="flex flex-col md:flex-row items-center gap-8">
                <div class="md:w-1/2 p-4">
                    <div class="relative rounded-xl overflow-hidden shadow-lg">
                        <img src="https://hormozgan.ac.ir/fileupload/13_32/N52564715863511648719459239.jpg" alt="Art School Students" class="w-full h-auto">
                        <div class="absolute -bottom-4 -right-4 bg-purple-600 text-white p-4 rounded-lg shadow-lg floating-icon">
                            <i class="fas fa-award text-4xl"></i>
                        </div>
                    </div>
                </div>
                <div class="md:w-1/2 md:pr-12">
                    <h3 class="text-2xl font-bold text-gray-800 mb-4">مدرسه‌ای برای ساختن آینده</h3>
                    <p class="text-gray-600 mb-6 leading-relaxed">
                        هنرستان فنی و حرفه‌ای دخترانه امیر کبیر با بیش از 18 سال سابقه درخشان در تربیت نیروی متخصص زن، یکی از بهترین مراکز آموزشی در منطقه است. ما با بهره‌گیری از کادری مجرب و امکانات مدرن آموزشی، زمینه را برای شکوفایی استعدادهای هنرجویان فراهم کرده‌ایم.
                    </p>
                    <div class="grid grid-cols-2 gap-4">
                        <div class="bg-purple-50 p-4 rounded-lg border border-purple-100 flex items-center">
                            <i class="fas fa-check-circle text-purple-600 text-2xl ml-3"></i>
                            <span>آموزش عملی محور</span>
                        </div>
                        <div class="bg-purple-50 p-4 rounded-lg border border-purple-100 flex items-center">
                            <i class="fas fa-check-circle text-purple-600 text-2xl ml-3"></i>
                            <span>کارگاه‌های مجهز</span>
                        </div>
                        <div class="bg-purple-50 p-4 rounded-lg border border-purple-100 flex items-center">
                            <i class="fas fa-check-circle text-purple-600 text-2xl ml-3"></i>
                            <span>اساتید متخصص</span>
                        </div>
                        <div class="bg-purple-50 p-4 rounded-lg border border-purple-100 flex items-center">
                            <i class="fas fa-check-circle text-purple-600 text-2xl ml-3"></i>
                            <span>حمایت از طرح‌های نوآورانه</span>
                        </div>
                    </div>
                    <a href="about.php" class="inline-block bg-purple-600 text-white py-3 px-6 rounded-full hover:bg-purple-700 transition duration-300 mt-4">
                        بیشتر بخوانید <i class="fas fa-book-open mr-2"></i>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Courses Section -->
    <section id="courses" class="py-16 bg-white">
        <div class="container mx-auto px-6">
            <div class="text-center mb-12">
                <h2 class="text-3xl md:text-4xl font-bold text-gray-800 mb-4">رشته‌های تحصیلی</h2>
                <div class="w-24 h-1 bg-purple-600 mx-auto rounded-full"></div>
                <p class="text-gray-600 max-w-2xl mx-auto mt-4">
                    هنرستان امیرکبیر با ارائه رشته‌های متنوع فنی و حرفه‌ای، زمینه را برای آموزش مهارت‌های کاربردی و بازارکار فراهم کرده است.
                </p>
            </div>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <div class="course-card bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition duration-500 w-80 mx-auto">
    <div class="flip-card h-96">
        <div class="flip-card-inner h-full">
            <!-- Front Side (Default View: Image + Title) -->
            <div class="flip-card-front h-full bg-white">
                <div class="h-48 overflow-hidden">
                    <img src="https://sina-pub.ir/storage/old/media-center/images/ac-image-kZ15402980269E.jpeg" alt=" شبه و نرم افزار  " class="w-full h-full object-cover">
                </div>
                <div class="p-4 text-center">
                    <h3 class="text-xl font-bold text-gray-800 mb-2"> شبکه و نرم افزار </h3>
                    <span class="bg-purple-100 text-purple-800 text-sm font-semibold px-3 py-1 rounded-full">فنی و حرفه‌ای</span>
                </div>
            </div>

            <!-- Back Side (On Hover: Details) -->
            <div class="flip-card-back bg-purple-600 text-white p-6 flex flex-col items-center justify-center h-full text-center">
                <h3 class="text-xl font-bold mb-2">جزئیات رشته</h3>
                <ul class="text-sm space-y-2 mb-4">
                    <li>اکسل، ورد، و نرم‌افزارهای گرافیکی</li>
                    <li>مفاهیم برنامه نویسی و شبکه</li>
                    <li>مدیریت اطلاعات و بانک های بایگانی</li>
                    <li>تحلیل داده‌های و طراحی وب</li>
                </ul>
                
            </div>
        </div>
    </div>
</div>

<!-- 🔽 Inline Style مخصوص flip بدون نیاز به CSS خارجی -->
<style>
    .flip-card {
        perspective: 1000px;
        position: relative;
    }
    .flip-card-inner {
        position: relative;
        width: 100%;
        height: 100%;
        transition: transform 0.6s;
        transform-style: preserve-3d;
    }
    .flip-card:hover .flip-card-inner {
        transform: rotateY(180deg);
    }
    .flip-card-front,
    .flip-card-back {
        backface-visibility: hidden;
        position: absolute;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
    }
    .flip-card-back {
        transform: rotateY(180deg);
    }
</style>

                
                <!-- Course 2 -->
                <div class="course-card bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition duration-500 w-80 mx-auto">
    <div class="flip-card h-96">
        <div class="flip-card-inner h-full">
            <!-- Front Side (Default View: Image + Title) -->
            <div class="flip-card-front h-full bg-white">
                <div class="h-48 overflow-hidden">
                    <img src="https://bayanbox.ir/download/7202578891211829556/dastyarilebas2.jpg" alt="طراحی دوخت" class="w-full h-full object-cover">
                </div>
                <div class="p-4 text-center">
                    <h3 class="text-xl font-bold text-gray-800 mb-2">طراحی دوخت</h3>
                    <span class="bg-pink-100 text-pink-800 text-sm font-semibold px-3 py-1 rounded-full">فنی و حرفه‌ای</span>
                </div>
            </div>

            <!-- Back Side (On Hover: Details) -->
            <div class="flip-card-back bg-pink-600 text-white p-6 flex flex-col items-center justify-center h-full text-center">
                <h3 class="text-xl font-bold mb-2">جزئیات رشته</h3>
                <ul class="text-sm space-y-2 mb-4">
                    <li>آموزش الگو سازی و برش</li>
                    <li>دوخت انواع لباس زنانه و مردانه</li>
                    <li>طراحی لباس با نرم‌افزار</li>
                    <li>آشنایی با مد و فشن</li>
                </ul>
                
            </div>
        </div>
    </div>
</div>



                
                <!-- Course 3 -->
                <div class="course-card bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition duration-500 w-80 mx-auto">
    <div class="flip-card h-96">
        <div class="flip-card-inner h-full">
            <!-- Front -->
            <div class="flip-card-front h-full bg-white">
                <div class="h-48 overflow-hidden">
                    <img src="https://www.beytoote.com/images/stories/scientific/childcare2.jpg" alt="تربیت کودک" class="w-full h-full object-cover">
                </div>
                <div class="p-4 text-center">
                    <h3 class="text-xl font-bold text-gray-800 mb-2">تربیت کودک</h3>
                    <span class="bg-yellow-100 text-yellow-800 text-sm font-semibold px-3 py-1 rounded-full">علوم انسانی</span>
                </div>
            </div>
            <!-- Back -->
            <div class="flip-card-back bg-yellow-500 text-white p-6 flex flex-col items-center justify-center h-full text-center">
                <h3 class="text-xl font-bold mb-2">جزئیات رشته</h3>
                <ul class="text-sm space-y-2 mb-4">
                    <li>روانشناسی رشد و کودک</li>
                    <li>آموزش بازی‌محور و خلاقیت</li>
                    <li>مراقبت جسمی و عاطفی</li>
                    <li>ارتباط با خانواده و جامعه</li>
                </ul>
                
            </div>
        </div>
    </div>
</div>

                
                <!-- Course 4 -->
                <div class="course-card bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition duration-500 w-80 mx-auto">
    <div class="flip-card h-96">
        <div class="flip-card-inner h-full">
            <!-- Front -->
            <div class="flip-card-front h-full bg-white">
                <div class="h-48 overflow-hidden">
                    <img src="https://4khooneh.org/wp-content/uploads/2020/12/g2.jpg" alt="گرافیک" class="w-full h-full object-cover">
                </div>
                <div class="p-4 text-center">
                    <h3 class="text-xl font-bold text-gray-800 mb-2">گرافیک</h3>
                    <span class="bg-purple-100 text-purple-800 text-sm font-semibold px-3 py-1 rounded-full">هنری</span>
                </div>
            </div>
            <!-- Back -->
            <div class="flip-card-back bg-purple-600 text-white p-6 flex flex-col items-center justify-center h-full text-center">
                <h3 class="text-xl font-bold mb-2">جزئیات رشته</h3>
                <ul class="text-sm space-y-2 mb-4">
                    <li>مبانی هنرهای تجسمی</li>
                    <li>طراحی پوستر و تبلیغات</li>
                    <li>نرم‌افزارهای گرافیکی (فتوشاپ/ایلاستریتور)</li>
                    <li>هویت بصری و برندینگ</li>
                </ul>
               
            </div>
        </div>
    </div>
</div>

                <!-- Course 5 -->
                <div class="course-card bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition duration-500 w-80 mx-auto">
    <div class="flip-card h-96">
        <div class="flip-card-inner h-full">
            <!-- Front -->
            <div class="flip-card-front h-full bg-white">
                <div class="h-48 overflow-hidden">
                    <img src="https://armancollege.ac.ir/wp-content/uploads/2023/02/%D9%81%D8%B1%D9%82-%D8%A8%DB%8C%D9%86-%D8%B1%D8%B4%D8%AA%D9%87-%D8%B9%DA%A9%D8%A7%D8%B3%DB%8C-%D8%AF%DB%8C%D8%AC%DB%8C%D8%AA%D8%A7%D9%84-%D8%A8%D8%A7-%D9%81%D8%AA%D9%88%DA%AF%D8%B1%D8%A7%D9%81%DB%8C%DA%A9.jpg" alt="فتوگرافیک" class="w-full h-full object-cover">
                </div>
                <div class="p-4 text-center">
                    <h3 class="text-xl font-bold text-gray-800 mb-2">فتوگرافیک</h3>
                    <span class="bg-blue-100 text-blue-800 text-sm font-semibold px-3 py-1 rounded-full">هنری</span>
                </div>
            </div>
            <!-- Back -->
            <div class="flip-card-back bg-blue-600 text-white p-6 flex flex-col items-center justify-center h-full text-center">
                <h3 class="text-xl font-bold mb-2">جزئیات رشته</h3>
                <ul class="text-sm space-y-2 mb-4">
                    <li>مبانی عکاسی و نورپردازی</li>
                    <li>ترکیب‌بندی و زیبایی‌شناسی</li>
                    <li>ویرایش حرفه‌ای با لایت‌روم و فتوشاپ</li>
                    <li>عکاسی صنعتی، تبلیغاتی و خبری</li>
                </ul>
               
            </div>
        </div>
    </div>
</div>

        </div>
    </section>

       <!-- Gallery Section -->
     
            <?php
session_start();
include("connec.php");
mysqli_set_charset($connect, "utf8mb4");
?>

<section id="gallery" class="py-16 bg-gray-50">
        <div class="container mx-auto px-6">
            <div class="text-center mb-12">
                <h2 class="text-3xl md:text-4xl font-bold text-gray-800 mb-4">گالری تصاویر</h2>
                <div class="w-24 h-1 bg-purple-600 mx-auto rounded-full"></div>
                <p class="text-gray-600 max-w-2xl mx-auto mt-4">
                    گوشه‌ای از فعالیت‌ها و محیط آموزشی هنرستان دخترانه امیرکبیر
                </p>
            </div>

    <main class="max-w-7xl mx-auto px-4 py-10">
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            <?php
            $select_query = "SELECT * FROM images";
            $result = mysqli_query($connect, $select_query);

            if (!$result) {
                echo "<div class='text-red-600 font-bold'>خطا در بارگذاری تصاویر: " . mysqli_error($connect) . "</div>";
            } else {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<div class="group relative overflow-hidden rounded-xl shadow-md hover:shadow-xl transition duration-300">';
                    echo '<img src="' . htmlspecialchars($row['image_url']) . '" alt="' . htmlspecialchars($row['name']) . '" class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">';
                    echo '<div class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition duration-300 flex items-end p-6">';
                    echo '<div>';
                    echo '<h3 class="text-white text-lg font-semibold">' . htmlspecialchars($row['name']) . '</h3>';
                    echo '<p class="text-purple-200 text-sm">' . htmlspecialchars($row['description']) . '</p>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            }
            ?>
        </div>
    </main>
</div>
            <div class="text-center mt-12">
                <a href="galre.php" class="inline-block border-2 border-purple-600 text-purple-600 py-3 px-8 rounded-full hover:bg-purple-600 hover:text-white transition duration-300">
                    مشاهده گالری کامل <i class="fas fa-images ml-2"></i>
                </a>
            </div>
        </div>
    </section>
    <!-- Events Section -->
    
    <?php
ob_start(); // فعال کردن output buffering
//session_start(); // اگر نیاز داری

mysqli_set_charset($connect, "utf8mb4");
?>


<section class="py-16 bg-white">
        <div class="container mx-auto px-4">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-purple-800 mb-4">رویدادها و اخبار</h2>
                <p class="text-gray-600 max-w-2xl mx-auto">جدیدترین رویدادها و اخبار هنرستان دخترانه امیر کبیر</p>
                <div class="w-20 h-1 bg-purple-600 mx-auto"></div>
            </div>

        <main class="max-w-7xl mx-auto px-4 py-10">
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                <?php
                $select_query = "SELECT * FROM events ORDER BY id DESC";
                $result = mysqli_query($connect, $select_query);

                if (!$result) {
                    echo "<div class='text-red-600 font-bold'>خطا در بارگذاری رویدادها: " . mysqli_error($connect) . "</div>";
                } else {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo '<div class="group relative overflow-hidden rounded-xl shadow-md hover:shadow-xl transition duration-300 flex flex-col">';
                        echo '<img src="' . htmlspecialchars($row['image_url']) . '" alt="' . htmlspecialchars($row['title']) . '" class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">';
                        echo '<div class="p-6 flex-grow flex flex-col justify-between">';
                        echo '<h3 class="text-lg font-semibold text-gray-800 mb-2">' . htmlspecialchars($row['title']) . '</h3>';
                        echo '<p class="text-gray-600 text-sm">' . nl2br(htmlspecialchars($row['description'])) . '</p>';
                      
                        echo '</div>';
                        echo '</div>';
                    }
                }
                
ob_end_flush(); 
                ?>
            </div>
        </main>
    </div>

            <div class="text-center mt-12">
                <a href="events.php" class="inline-block bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-8 rounded-lg transition shadow-lg">
                    مشاهده همه رویدادها <i class="fas fa-chevron-left mr-2"></i>
                </a>
            </div>
        </div>
        

    </section>


<!-- Register Section -->
<?php
ob_start();
include("connec.php");
mysqli_set_charset($connect, "utf8mb4");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = mysqli_real_escape_string($connect, $_POST['name']);
    $phone = mysqli_real_escape_string($connect, $_POST['phone']);
    $course = mysqli_real_escape_string($connect, $_POST['course']);
    $message = mysqli_real_escape_string($connect, $_POST['message']);

    $query = "INSERT INTO register_form (name, phone, course, message) VALUES ('$name', '$phone', '$course', '$message')";
    $result = mysqli_query($connect, $query);

    $success = $result ? true : false;
}
?>



<section id="register" class="py-16 bg-purple-800 text-white">
    <div class="container mx-auto px-4">
        <div class="flex flex-col md:flex-row items-center">
            <div class="md:w-1/2 mb-8 md:mb-0 md:pl-12">
                <h2 class="text-3xl font-bold mb-4">ثبت نام در هنرستان امیر کبیر</h2>
                <p class="text-purple-100 mb-6 leading-relaxed">
                    برای ثبت نام در هنرستان دخترانه امیر کبیر فرم زیر را پر کنید. کارشناسان ما در اسرع وقت با شما تماس خواهند گرفت.
                </p>
                <div class="space-y-4">
                    <div class="flex items-start">
                        <div class="text-purple-300 mt-1 ml-3"><i class="fas fa-check-circle"></i></div>
                        <div>
                            <h4 class="font-bold">مشاوره رایگان</h4>
                            <p class="text-purple-100">مشاوران ما آماده پاسخگویی به سوالات شما هستند</p>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="text-purple-300 mt-1 ml-3"><i class="fas fa-check-circle"></i></div>
                        <div>
                            <h4 class="font-bold">پشتیبانی تمام وقت</h4>
                            <p class="text-purple-100">همراهی و پشتیبانی هنرجویان در تمام مراحل تحصیل</p>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="text-purple-300 mt-1 ml-3"><i class="fas fa-check-circle"></i></div>
                        <div>
                            <h4 class="font-bold">برگزاری آزمون تعیین سطح</h4>
                            <p class="text-purple-100">برگزاری آزمون رایگان برای انتخاب رشته مناسب</p>
                        </div>
                    </div>
                </div>
            </div>

            
<div class="max-w-3xl mx-auto mt-12 p-10 bg-white rounded-3xl shadow-xl border border-purple-300">
    <h2 class="text-3xl font-extrabold text-purple-800 mb-8 text-center border-b border-purple-300 pb-3">فرم پیش ثبت‌نام</h2>

    <?php if (isset($success) && $success): ?>
        <div class="mb-6 p-4 bg-green-100 border border-green-300 text-green-800 rounded-xl text-center shadow">
            ✅ فرم شما با موفقیت ثبت شد. کارشناسان ما به‌زودی با شما تماس خواهند گرفت.
        </div>
    <?php endif; ?>

    <form method="POST" class="space-y-6">
    <div>
        <label class="block mb-2 text-right font-semibold text-purple-700">نام و نام خانوادگی</label>
        <input name="name" required
            class="w-full text-gray-800 border border-purple-300 rounded-xl px-5 py-3 focus:outline-none focus:ring-4 focus:ring-purple-400 focus:border-purple-600 transition"
            type="text" />
    </div>

    <div>
        <label class="block mb-2 text-right font-semibold text-purple-700">شماره تماس</label>
        <input name="phone" required
            class="w-full text-gray-800 border border-purple-300 rounded-xl px-5 py-3 focus:outline-none focus:ring-4 focus:ring-purple-400 focus:border-purple-600 transition"
            type="tel" />
    </div>

    <div>
        <label class="block mb-2 text-right font-semibold text-purple-700">رشته مورد علاقه</label>
        <select name="course" required
            class="w-full text-gray-800 border border-purple-300 rounded-xl px-5 py-3 focus:outline-none focus:ring-4 focus:ring-purple-400 focus:border-purple-600 transition">
            <option value="">-- انتخاب کنید --</option>
            <option value=" شبکه و نرم افزار ">شبکه و نرم‌افزار</option>
            <option value="طراحی و دوخت">طراحی و دوخت</option>
            <option value="گرافیک ">گرافیک</option>
            <option value=" فتوگرافیک">فتوگرافیک</option>
            <option value="تربیت کودک  ">تربیت کودک</option>
        </select>
    </div>

    <div>
        <label class="block mb-2 text-right font-semibold text-purple-700">توضیحات (اختیاری)</label>
        <textarea name="message" rows="4"
            class="w-full text-gray-800 border border-purple-300 rounded-xl px-5 py-3 focus:outline-none focus:ring-4 focus:ring-purple-400 focus:border-purple-600 transition resize-none"></textarea>
    </div>

    <button type="submit"
        class="w-full bg-gradient-to-r from-purple-500 to-purple-700 hover:from-purple-600 hover:to-purple-800 text-white font-extrabold py-4 rounded-2xl shadow-lg transition duration-300">
        ارسال درخواست
    </button>
</form>

</div>
        </div>
    </div>
</section>



    <!-- Contact Section -->
    <section id="contact" class="py-16 bg-white">
        <div class="container mx-auto px-4">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-purple-800 mb-4">تماس با ما</h2>
                <p class="text-gray-600 max-w-2xl mx-auto">برای دریافت اطلاعات بیشتر با ما در ارتباط باشید</p>
                <div class="w-20 h-1 bg-purple-600 mx-auto"></div>
            </div>
            
            <div class="flex flex-col md:flex-row">
                <div class="md:w-1/2 mb-8 md:mb-0 md:pl-12">
                    <div class="mb-8">
                        <h3 class="text-xl font-bold text-gray-800 mb-4">اطلاعات تماس</h3>
                        <div class="space-y-4">
                            <div class="flex items-start">
                                <div class="text-purple-600 mt-1 ml-3"><i class="fas fa-map-marker-alt"></i></div>
                                <div>
                                    <h4 class="font-bold text-gray-800">آدرس</h4>
                                    <p class="text-gray-600">تهران، خیابان انقلاب، کوچه شهید فلانی، پلاک 123</p>
                                </div>
                            </div>
                            <div class="flex items-start">
                                <div class="text-purple-600 mt-1 ml-3"><i class="fas fa-phone-alt"></i></div>
                                <div>
                                    <h4 class="font-bold text-gray-800">تلفن</h4>
                                    <p class="text-gray-600">021-12345678 - 021-87654321</p>
                                </div>
                            </div>
                            <div class="flex items-start">
                                <div class="text-purple-600 mt-1 ml-3"><i class="fas fa-envelope"></i></div>
                                <div>
                                    <h4 class="font-bold text-gray-800">ایمیل</h4>
                                    <p class="text-gray-600">info@amirkabir-school.ir</p>
                                </div>
                            </div>
                            <div class="flex items-start">
                                <div class="text-purple-600 mt-1 ml-3"><i class="fas fa-clock"></i></div>
                                <div>
                                    <h4 class="font-bold text-gray-800">ساعات کاری</h4>
                                    <p class="text-gray-600">شنبه تا چهارشنبه: 7:30 صبح تا 2 بعدازظهر</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <h3 class="text-xl font-bold text-gray-800 mb-4">ما را در شبکه‌های اجتماعی دنبال کنید</h3>
                        <div class="flex space-x-4 space-x-reverse">
                            <a href="#" class="w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center hover:bg-blue-600 transition">
                                <i class="fab fa-telegram-plane"></i>
                            </a>
                            <a href="#" class="w-10 h-10 bg-purple-600 text-white rounded-full flex items-center justify-center hover:bg-purple-700 transition">
                                <i class="fab fa-instagram"></i>
                            </a>
                            <a href="#" class="w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center hover:bg-blue-700 transition">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="#" class="w-10 h-10 bg-red-600 text-white rounded-full flex items-center justify-center hover:bg-red-700 transition">
                                <i class="fab fa-youtube"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="md:w-1/2">
                    <div class="bg-gray-50 p-8 rounded-lg shadow-md">
                        <h3 class="text-xl font-bold text-gray-800 mb-6">پیام به هنرستان</h3>
                        <form id="contact-form">
                            <div class="mb-4">
                                <label for="contact-name" class="block text-gray-700 font-medium mb-2">نام و نام خانوادگی</label>
                                <input type="text" id="contact-name" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500">
                            </div>
                            <div class="mb-4">
                                <label for="contact-email" class="block text-gray-700 font-medium mb-2">ایمیل</label>
                                <input type="email" id="contact-email" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500">
                            </div>
                            <div class="mb-4">
                                <label for="contact-subject" class="block text-gray-700 font-medium mb-2">موضوع</label>
                                <input type="text" id="contact-subject" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500">
                            </div>
                            <div class="mb-6">
                                <label for="contact-message" class="block text-gray-700 font-medium mb-2">متن پیام</label>
                                <textarea id="contact-message" rows="4" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"></textarea>
                            </div>
                            <button type="submit" class="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-4 rounded-lg transition shadow-lg">
                                ارسال پیام
                            </button>
                        </form>
                        <div id="contact-success" class="hidden mt-4 p-4 bg-green-100 text-green-700 rounded-lg text-center">
                            <i class="fas fa-check-circle text-green-500 text-2xl mb-2"></i>
                            <p>پیام شما با موفقیت ارسال شد. در اسرع وقت پاسخ داده خواهد شد.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Map Section -->
    <div class="h-96 w-full overflow-hidden">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3240.8278533985533!2d51.39182121528841!3d35.69688798019116!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzXCsDQxJzQ4LjgiTiA1McKwMjMnMzYuOSJF!5e0!3m2!1sen!2sus!4v1620000000000!5m2!1sen!2sus" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    </div>

    <!-- Back to Top Button -->
    <button id="back-to-top" class="fixed bottom-6 left-6 bg-purple-600 text-white p-3 rounded-full shadow-lg hover:bg-purple-700 transition hidden">
        <i class="fas fa-arrow-up"></i>
    </button>

    <!-- Loading Spinner -->
    <div id="loading-spinner" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden">
        <div class="spinner"></div>
    </div>

    <script>
        // Mobile menu toggle
        document.getElementById('mobile-menu-button').addEventListener('click', function() {
            const mobileMenu = document.getElementById('mobile-menu');
            mobileMenu.classList.toggle('hidden');
        });

        // Registration form submission
        document.getElementById('registration-form').addEventListener('submit', function(e) {
            e.preventDefault();
            document.getElementById('loading-spinner').classList.remove('hidden');
            
            // Simulate form submission
            setTimeout(function() {
                document.getElementById('loading-spinner').classList.add('hidden');
                document.getElementById('registration-form').reset();
                document.getElementById('success-message').classList.remove('hidden');
                
                setTimeout(function() {
                    document.getElementById('success-message').classList.add('hidden');
                }, 5000);
            }, 2000);
        });

        // Contact form submission
        document.getElementById('contact-form').addEventListener('submit', function(e) {
            e.preventDefault();
            document.getElementById('loading-spinner').classList.remove('hidden');
            
            // Simulate form submission
            setTimeout(function() {
                document.getElementById('loading-spinner').classList.add('hidden');
                document.getElementById('contact-form').reset();
                document.getElementById('contact-success').classList.remove('hidden');
                
                setTimeout(function() {
                    document.getElementById('contact-success').classList.add('hidden');
                }, 5000);
            }, 2000);
        });

        // Back to top button
        window.addEventListener('scroll', function() {
            const backToTopButton = document.getElementById('back-to-top');
            if (window.pageYOffset > 300) {
                backToTopButton.classList.remove('hidden');
            } else {
                backToTopButton.classList.add('hidden');
            }
        });

        document.getElementById('back-to-top').addEventListener('click', function() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    targetElement.scrollIntoView({ behavior: 'smooth' });
                    
                    // Close mobile menu if open
                    const mobileMenu = document.getElementById('mobile-menu');
                    if (!mobileMenu.classList.contains('hidden')) {
                        mobileMenu.classList.add('hidden');
                    }
                }
            });
        });

        // Initialize marquee animation
        const marquee = document.querySelector('.marquee');
        const marqueeContent = marquee.innerHTML;
        marquee.innerHTML = marqueeContent + marqueeContent;
    </script>
</body>
</html>
<?php include 'footer.php'; ?>