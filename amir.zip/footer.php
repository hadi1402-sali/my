
    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-12">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                    <h3 class="text-xl font-bold mb-4">هنرستان امیر کبیر</h3>
                    <p class="text-gray-300 mb-4">هنرستان فنی و حرفه‌ای دخترانه امیر کبیر با سابقه‌ای درخشان در تربیت نیروی متخصص زن</p>
                    <div class="flex space-x-4 space-x-reverse">
                        <a href="#" class="text-gray-400 hover:text-white transition">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white transition">
                            <i class="fab fa-telegram-plane"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white transition">
                            <i class="fab fa-youtube"></i>
                        </a>
                    </div>
                </div>
                
                <div>
                    <h3 class="text-lg font-bold mb-4">لینک‌های مفید</h3>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-300 hover:text-white transition">آموزش و پرورش</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white transition">سامانه همگام</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white transition">سامانه سیدا</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white transition">کانال اطلاع‌رسانی</a></li>
                    </ul>
                </div>
                
                <div>
                    <h3 class="text-lg font-bold mb-4">رشته‌های تحصیلی</h3>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-300 hover:text-white transition">نرم‌افزار و حسابداری</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white transition">طراحی و دوخت</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white transition">گرافیک کامپیوتری</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white transition">حسابداری مالی</a></li>
                    </ul>
                </div>
                
                <div>
                    <h3 class="text-lg font-bold mb-4">خبرنامه</h3>
                    <p class="text-gray-300 mb-4">برای دریافت آخرین اخبار و اطلاعیه‌ها ایمیل خود را ثبت کنید</p>
                    <form class="flex">
                        <input type="email" placeholder="ایمیل شما" class="px-4 py-2 text-gray-800 rounded-r-lg focus:outline-none w-full">
                        <button type="submit" class="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded-l-lg">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </form>
                </div>
            </div>
            
            <div class="border-t border-gray-800 mt-10 pt-6 text-center text-gray-400">
                <p>تمامی حقوق مادی و معنوی این وبسایت متعلق به هنرستان فنی و حرفه‌ای دخترانه امیر کبیر می‌باشد. © 1402</p>
            </div>
        </div>
    </footer>
