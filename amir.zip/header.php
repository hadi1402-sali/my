<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>هنرستان دخترانه امیر کبیر</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Noto+Naskh+Arabic:wght@400;500;600;700&display=swap');
        
        body {
            font-family: 'Noto Naskh Arabic', serif;
            background-color: #f5f7fa;
        }
        
        .hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://images.unsplash.com/photo-1523050854058-8df90110c9f1?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
        }
        
        .course-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
        .event-card {
            transition: all 0.3s ease;
        }
        
        .event-card:hover {
            transform: scale(1.03);
        }
        
        .navbar {
            backdrop-filter: blur(10px);
        }
        
        .marquee {
            animation: marquee 15s linear infinite;
        }
        
        @keyframes marquee {
            0% { transform: translateX(0); }
            100% { transform: translateX(-50%); }
        }
        
        /* Custom spinner for loading */
        .spinner {
            width: 40px;
            height: 40px;
            border: 4px solid rgba(0, 0, 0, 0.1);
            border-left-color: #4f46e5;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar fixed top-0 w-full bg-purple-800 text-white shadow-lg z-50">
        <div class="container mx-auto px-4 py-3">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4 space-x-reverse">
                    <div class="flex items-center">
                        <i class="fas fa-school text-2xl text-purple-200"></i>
                        <a href="#" class="text-xl font-bold mr-2 hover:text-purple-200">هنرستان امیر کبیر</a>
                    </div>
                </div>
                
                <div class="hidden md:flex items-center space-x-6 space-x-reverse">
                    <a href="index.php" class="hover:text-purple-200 transition">بازگشت به صفحه اصلی</a>
                </div>
                
                <button class="md:hidden text-white focus:outline-none" id="mobile-menu-button">
                    <i class="fas fa-bars text-2xl"></i>
                </button>
            </div>
        </div>
        
        <!-- Mobile menu -->
        <div class="hidden md:hidden bg-purple-700 w-full" id="mobile-menu">
            <div class="px-2 py-3 space-y-3 space-y-reverse">
                <a href="#home" class="block px-3 py-2 hover:bg-purple-600 rounded">صفحه اصلی</a>
                <a href="#about" class="block px-3 py-2 hover:bg-purple-600 rounded">درباره ما</a>
                <a href="#courses" class="block px-3 py-2 hover:bg-purple-600 rounded">رشته‌ها</a>
                <a href="#gallery" class="block px-3 py-2 hover:bg-purple-600 rounded">گالری</a>
                <a href="#contact" class="block px-3 py-2 hover:bg-purple-600 rounded">تماس با ما</a>
            </div>
        </div>
    </nav>