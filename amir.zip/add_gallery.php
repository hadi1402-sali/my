<?php
include("header.php");
include("connec.php");
mysqli_set_charset($connect, "utf8mb4");
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $image_url = "";

    if (!empty($_FILES['image']['name'])) {
        $target_dir = "images/gallery/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);
        $filename = time() . "_" . basename($_FILES["image"]["name"]);
        $image_url = $target_dir . $filename;

        if (!move_uploaded_file($_FILES["image"]["tmp_name"], $image_url)) {
            echo "<div class='text-red-600 font-bold my-4'>❌ خطا در آپلود تصویر.</div>";
            $image_url = "";
        }
    }

    $stmt = mysqli_prepare($connect, "INSERT INTO images (name, description, image_url) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "sss", $name, $description, $image_url);

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success'] = "✅ عکس با موفقیت اضافه شد.";
        header("Location: login_action.php");
        exit;
    } else {
        echo "<div class='text-red-600 font-bold my-4'>❌ خطا در ثبت عکس: " . mysqli_error($connect) . "</div>";
    }
}
?>

<div class="max-w-3xl mx-auto mt-10 p-6 bg-white rounded-xl shadow-md">
    <h2 class="text-2xl font-bold text-purple-700 mb-6 text-center border-b pb-2">➕ افزودن عکس جدید</h2>
    
    <form method="post" enctype="multipart/form-data" class="space-y-6">
        <div>
            <label class="block mb-1 text-right font-medium text-gray-700">نام عکس</label>
            <input name="name" required class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500" type="text">
        </div>

        <div>
            <label class="block mb-1 text-right font-medium text-gray-700">توضیحات</label>
            <textarea name="description" rows="4" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"></textarea>
        </div>

        <div>
            <label class="block mb-1 text-right font-medium text-gray-700">تصویر</label>
            <input name="image" required class="w-full border border-gray-300 rounded-lg px-4 py-2 file:bg-purple-600 file:text-white file:rounded file:px-4 file:py-1" type="file" accept="image/*">
        </div>

        <div>
            <button type="submit" class="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-6 rounded-lg transition duration-200">
                📥 ثبت عکس
            </button>
        </div>
    </form>
</div>

<?php include("footer.php"); ?>
