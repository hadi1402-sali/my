<?php include("header.php"); ?>
<?php
session_start();
include("connec.php");
mysqli_set_charset($connect, "utf8mb4");
?>

<section id="gallery" class="py-16 bg-gray-50">
        <div class="container mx-auto px-6">
            <div class="text-center mb-12">
                <h2 class="text-3xl md:text-4xl font-bold text-gray-800 mb-4">گالری تصاویر</h2>
                <div class="w-24 h-1 bg-purple-600 mx-auto rounded-full"></div>
                <p class="text-gray-600 max-w-2xl mx-auto mt-4">
                    گوشه‌ای از فعالیت‌ها و محیط آموزشی هنرستان دخترانه امیرکبیر
                </p>
            </div>
    <main class="max-w-7xl mx-auto px-4 py-10">
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            <?php
            $select_query = "SELECT * FROM images";
            $result = mysqli_query($connect, $select_query);

            if (!$result) {
                echo "<div class='text-red-600 font-bold'>خطا در بارگذاری تصاویر: " . mysqli_error($connect) . "</div>";
            } else {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<div class="group relative overflow-hidden rounded-xl shadow-md hover:shadow-xl transition duration-300">';
                    echo '<img src="' . htmlspecialchars($row['image_url']) . '" alt="' . htmlspecialchars($row['name']) . '" class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">';
                    echo '<div class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition duration-300 flex items-end p-6">';
                    echo '<div>';
                    echo '<h3 class="text-white text-lg font-semibold">' . htmlspecialchars($row['name']) . '</h3>';
                    echo '<p class="text-purple-200 text-sm">' . htmlspecialchars($row['description']) . '</p>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            }
            ?>
        </div>
    </main>
</div>

<?php include("footer.php"); ?>
