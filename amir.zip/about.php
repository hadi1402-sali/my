<?php include 'header.php'; ?>
    <!-- Timeline Section -->
    <section class="py-16 bg-purple-50">
        <div class="container mx-auto px-6">
            <div class="text-center mb-12">
                <h2 class="text-3xl md:text-4xl font-bold text-gray-800 mb-4">مسیر پیشرفت ما</h2>
                <div class="w-24 h-1 bg-purple-600 mx-auto rounded-full"></div>
            </div>
            
            <div class="relative">
                <div class="border-r-4 border-purple-600 absolute h-full right-1/2 hidden md:block"></div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <!-- Timeline Item 1 -->
                    <div class="relative timeline-item">
                        <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition relative md:mr-8">
                            <div class="absolute left-0 -mr-12 hidden md:block text-purple-600">
                                <div class="bg-purple-600 text-white rounded-full h-8 w-8 flex items-center justify-center">
                                    <i class="fas fa-school text-lg"></i>
                                </div>
                            </div>
                            <h3 class="text-xl font-bold text-gray-800 mb-2">تأسیس هنرستان</h3>
                            <p class="text-gray-600">سال 1380 - هنرستان دخترانه امیرکبیر با 3 رشته تحصیلی آغاز به کار کرد.</p>
                        </div>
                    </div>
                    
                    <!-- Timeline Item 2 -->
                    <div class="md:col-start-2 relative timeline-item">
                        <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition relative md:ml-8">
                            <div class="absolute left-0 -ml-16 hidden md:block text-purple-600">
                                <div class="bg-purple-600 text-white rounded-full h-8 w-8 flex items-center justify-center">
                                    <i class="fas fa-medal text-lg"></i>
                                </div>
                            </div>
                            <h3 class="text-xl font-bold text-gray-800 mb-2">کسب اولین جایزه استانی</h3>
                            <p class="text-gray-600">سال 1385 - کسب مقام اول در مسابقات مهارتی استان در رشته طراحی لباس.</p>
                        </div>
                    </div>
                    
                    <!-- Timeline Item 3 -->
                    <div class="relative timeline-item">
                        <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition relative md:mr-8">
                            <div class="absolute left-0 -mr-12 hidden md:block text-purple-600">
                                <div class="bg-purple-600 text-white rounded-full h-8 w-8 flex items-center justify-center">
                                    <i class="fas fa-expand-alt text-lg"></i>
                                </div>
                            </div>
                            <h3 class="text-xl font-bold text-gray-800 mb-2">گسترش رشته‌ها</h3>
                            <p class="text-gray-600">سال 1389 - اضافه شدن 5 رشته جدید شامل گرافیک رایانه‌ای، حسابداری و معماری.</p>
                        </div>
                    </div>
                    
                    <!-- Timeline Item 4 -->
                    <div class="md:col-start-2 relative timeline-item">
                        <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition relative md:ml-8">
                            <div class="absolute left-0 -ml-16 hidden md:block text-purple-600">
                                <div class="bg-purple-600 text-white rounded-full h-8 w-8 flex items-center justify-center">
                                    <i class="fas fa-certificate text-lg"></i>
                                </div>
                            </div>
                            <h3 class="text-xl font-bold text-gray-800 mb-2">رتبه برتر کشوری</h3>
                            <p class="text-gray-600">سال 1394 - کسب رتبه اول کشوری در المپیاد مهارتی رشته طراحی وب.</p>
                        </div>
                    </div>
                    
                    <!-- Timeline Item 5 -->
                    <div class="relative">
                        <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition relative md:mr-8">
                            <div class="absolute left-0 -mr-12 hidden md:block text-purple-600">
                                <div class="bg-purple-600 text-white rounded-full h-8 w-8 flex items-center justify-center">
                                    <i class="fas fa-star text-lg"></i>
                                </div>
                            </div>
                            <h3 class="text-xl font-bold text-gray-800 mb-2">هنرستان نمونه استان</h3>
                            <p class="text-gray-600">سال 1401 - انتخاب به عنوان هنرستان نمونه استان و تجهیز کامل کارگاه‌ها.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php include 'footer.php'; ?>