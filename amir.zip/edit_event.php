<?php
include("header.php");
$conn = new mysqli("localhost", "root", "", "amir");
$conn->set_charset("utf8mb4");

if (!isset($_GET['id'])) {
    echo "<div class='text-center text-red-600 mt-10'>رویداد مشخص نیست.</div>";
    include("footer.php");
    exit;
}

$id = intval($_GET['id']);
$res = $conn->query("SELECT * FROM events WHERE id = $id");
if (!$res) {
    die("خطا در اجرای کوئری: " . $conn->error);
}
$event = $res->fetch_assoc();

if (!$event) {
    echo "<div class='text-center text-red-600 mt-10'>رویداد یافت نشد.</div>";
    include("footer.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];

    if (!empty($_FILES['image']['name'])) {
        $image_path = 'images/' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $image_path);

        $stmt = $conn->prepare("UPDATE events SET title=?, description=?, image_url=? WHERE id=?");
        $stmt->bind_param("sssi", $title, $description, $image_path, $id);
    } else {
        $stmt = $conn->prepare("UPDATE events SET title=?, description=? WHERE id=?");
        $stmt->bind_param("ssi", $title, $description, $id);
    }

    $stmt->execute();
    header("Location: update_event.php");
    exit;
}
?>

<!-- فرم HTML اینجا نمایش داده می‌شود -->
<div class="max-w-3xl mx-auto px-4 py-10 fade-in">
    <div class="bg-white p-6 rounded-xl shadow-md">
        <h2 class="text-2xl font-bold text-purple-700 mb-6 text-center">ویرایش رویداد</h2>
        <form method="post" enctype="multipart/form-data" class="space-y-5">

            <div>
                <label class="block mb-1 text-sm font-medium text-gray-700 text-right">عنوان رویداد:</label>
                <input type="text" name="title" value="<?= htmlspecialchars($event['title']) ?>" class="w-full border border-gray-300 rounded-lg p-2 focus:ring-purple-500 focus:border-purple-500">
            </div>

            <div>
                <label class="block mb-1 text-sm font-medium text-gray-700 text-right">توضیحات:</label>
                <textarea name="description" rows="4" class="w-full border border-gray-300 rounded-lg p-2 focus:ring-purple-500 focus:border-purple-500"><?= htmlspecialchars($event['description']) ?></textarea>
            </div>

            <div>
                <label class="block mb-1 text-sm font-medium text-gray-700 text-right">عکس جدید (اختیاری):</label>
                <input type="file" name="image" class="w-full border border-gray-300 rounded-lg p-2">
            </div>

            <?php if (!empty($event['image_url'])): ?>
                <div class="text-center mt-4">
                    <p class="text-sm text-gray-500 mb-2">تصویر فعلی:</p>
                    <img src="<?= htmlspecialchars($event['image_url']) ?>" alt="تصویر فعلی" class="mx-auto rounded shadow-md max-w-xs">
                </div>
            <?php endif; ?>

            <div>
                <button type="submit" class="w-full bg-purple-600 text-white font-semibold py-3 rounded-lg hover:bg-purple-700 transition">
                    ذخیره تغییرات
                </button>
            </div>
        </form>
    </div>
</div>

<?php include("footer.php"); ?>
