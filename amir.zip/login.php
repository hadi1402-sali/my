<?php include("header.php"); ?>

<div class="flex items-center justify-center min-h-screen bg-gradient-to-br from-purple-100 to-purple-200 px-4">
    <div class="bg-white shadow-2xl rounded-2xl px-8 pt-8 pb-10 w-full max-w-md border border-purple-100">
        <h2 class="text-center text-3xl font-extrabold text-purple-700 mb-6">ورود به پنل مدیریت</h2>
        <form action="login_ac.php" method="post" class="space-y-6">
            <div>
                <label for="username" class="block text-right text-sm font-medium text-gray-700 mb-1">نام کاربری</label>
                <input type="text" id="username" name="username" required
                       class="block w-full rounded-lg border border-gray-300 shadow-sm py-2 px-3 text-gray-900 focus:ring-purple-500 focus:border-purple-500">
            </div>

            <div>
                <label for="password" class="block text-right text-sm font-medium text-gray-700 mb-1">رمز عبور</label>
                <input type="password" id="password" name="password" required
                       class="block w-full rounded-lg border border-gray-300 shadow-sm py-2 px-3 text-gray-900 focus:ring-purple-500 focus:border-purple-500">
            </div>

            <div class="flex items-center justify-between">
                <input type="submit" value="ورود"
                       class="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg transition duration-200">
            </div>
        </form>
    </div>
</div>

<?php include("footer.php"); ?>
