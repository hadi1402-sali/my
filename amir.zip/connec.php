<?php

$connect = new mysqli("localhost", "root", "", "amir");
if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
}
$connect->set_charset("utf8mb4");
//$connect = mysqli_connect("localhost", "h315931_horee", "fate6831", "h315931_myshopmahya");
//$conn = mysqli_connect("localhost","h315931_horee","fate6831","h315931_myshopmahya");
?>