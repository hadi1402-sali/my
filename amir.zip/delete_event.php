<?php
include("header.php");
include("connec.php");
mysqli_set_charset($connect, "utf8mb4");
session_start();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    $stmt = mysqli_prepare($connect, "DELETE FROM events WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);

    if (mysqli_stmt_affected_rows($stmt) > 0) {
        $_SESSION['success'] = "✅ رویداد با موفقیت حذف شد.";
    } else {
        $_SESSION['error'] = "❌ خطا در حذف رویداد یا رویداد یافت نشد.";
    }

    mysqli_stmt_close($stmt);
} else {
    $_SESSION['error'] = "❌ شناسه رویداد نامعتبر است.";
}

header("Location: login_action.php");
exit;
?>
