<?php
include("header.php");
include("connec.php");
mysqli_set_charset($connect, "utf8mb4");
?>

<div class="min-h-screen bg-gray-50">
    <nav class="bg-white shadow-md">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <span class="text-xl font-bold text-purple-700">پنل مدیریت اورلیک</span>
            <a href="index.php" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">خروج</a>
        </div>
    </nav>

    <main class="max-w-7xl mx-auto px-4 py-10 space-y-10">

        <!-- مدیریت رویدادها -->
        <section class="bg-white p-6 rounded-xl shadow-lg">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-xl font-bold text-gray-800">مدیریت رویدادها</h2>
                <a href="add_event.php" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg">+ رویداد جدید</a>
            </div>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-100 text-right text-sm font-semibold text-gray-600">
                    <tr>
                        <th class="px-4 py-3">عنوان</th>
                        <th class="px-4 py-3">توضیحات</th>
                        <th class="px-4 py-3">تصویر</th>
                        <th class="px-4 py-3">عملیات</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200 text-sm">
                    <?php
                    $events = mysqli_query($connect, "SELECT * FROM events ORDER BY id DESC");
                    while ($event = mysqli_fetch_assoc($events)) {
                        echo "<tr>";
                        echo "<td class='px-4 py-3'>" . htmlspecialchars($event['title']) . "</td>";
                        echo "<td class='px-4 py-3'>" . htmlspecialchars($event['description']) . "</td>";
                        echo "<td class='px-4 py-3'>
                        <img src='" . htmlspecialchars($event['image_url']) . "' class='w-20 h-20 rounded-lg object-cover'></td>";
                        echo "<td class='px-4 py-3 text-left'>
                                <a href='edit_event.php?id={$event['id']}' class='text-blue-600 ml-2'><i class='fas fa-edit'></i></a>
                                <a href='delete_event.php?id={$event['id']}' onclick=\"return confirm('حذف شود؟');\" class='text-red-600'><i class='fas fa-trash'></i></a>
                              </td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </section>

        <!-- مدیریت گالری -->
        <section class="bg-white p-6 rounded-xl shadow-lg">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-xl font-bold text-gray-800">مدیریت گالری تصاویر</h2>
                <a href="add_gallery.php" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg">+ تصویر جدید</a>
            </div>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-100 text-right text-sm font-semibold text-gray-600">
                    <tr>
                        <th class="px-4 py-3">عنوان</th>
                        <th class="px-4 py-3">توضیحات</th>
                        <th class="px-4 py-3">تصویر</th>
                        <th class="px-4 py-3">عملیات</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200 text-sm">
                    <?php
                    $gallery = mysqli_query($connect, "SELECT * FROM images ORDER BY id DESC");
                    while ($pic = mysqli_fetch_assoc($gallery)) {
                        echo "<tr>";
                        echo "<td class='px-4 py-3'>" . htmlspecialchars($pic['name']) . "</td>";
                        echo "<td class='px-4 py-3'>" . htmlspecialchars($pic['description']) . "</td>";
                        echo "<td class='px-4 py-3'>
                                <img src='" . htmlspecialchars($pic['image_url']) . "' class='w-20 h-20 rounded-lg object-cover'>
                              </td>";
                        echo "<td class='px-4 py-3 text-left'>
                                <a href='edit_gallery.php?id={$pic['id']}' class='text-blue-600 ml-2'><i class='fas fa-edit'></i></a>
                                <a href='delete_gallery.php?id={$pic['id']}' onclick=\"return confirm('حذف شود؟');\" class='text-red-600'><i class='fas fa-trash'></i></a>
                              </td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </section>

        <!-- لیست ثبت‌نامی‌ها -->
        <section class="bg-white p-6 rounded-xl shadow-lg">
            <h2 class="text-xl font-bold text-gray-800 mb-4">لیست ثبت‌نامی‌ها</h2>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-100 text-right text-sm font-semibold text-gray-600">
                    <tr>
                        <th class="px-4 py-3">نام</th>
                        <th class="px-4 py-3">شماره تماس</th>
                        <th class="px-4 py-3">رشته</th>
                        <th class="px-4 py-3">توضیحات</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200 text-sm">
                    <?php
                    $students = mysqli_query($connect, "SELECT * FROM register_form ORDER BY id DESC");
                    while ($s = mysqli_fetch_assoc($students)) {
                        echo "<tr>";
                        echo "<td class='px-4 py-3'>" . htmlspecialchars($s['name']) . "</td>";
                        echo "<td class='px-4 py-3'>" . htmlspecialchars($s['phone']) . "</td>";
                        echo "<td class='px-4 py-3'>" . htmlspecialchars($s['course']) . "</td>";
                        echo "<td class='px-4 py-3'>" . htmlspecialchars($s['message']) . "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </section>

    </main>
</div>

<?php
mysqli_close($connect);
include("footer.php");
?>
