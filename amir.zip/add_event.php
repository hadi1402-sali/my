<?php
include("header.php");
include("connec.php");
session_start();
mysqli_set_charset($connect, "utf8mb4");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);

    // آپلود عکس (اختیاری)
    $image_url = "";
    if (!empty($_FILES['image']['name'])) {
        $upload_dir = "images/";
        $image_url = $upload_dir . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $image_url);
    }

    $stmt = mysqli_prepare($connect, "INSERT INTO events (title, description, image_url) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "sss", $title, $description, $image_url);

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success'] = "✅ رویداد با موفقیت اضافه شد.";
        header("Location: login_action.php");
        exit;
    } else {
        echo "<div class='text-red-600 font-bold my-4'>❌ خطا در ثبت رویداد: " . mysqli_error($connect) . "</div>";
    }
}
?>

<div class="max-w-3xl mx-auto mt-10 p-6 bg-white rounded-xl shadow-md">
    <h2 class="text-2xl font-bold text-purple-700 mb-6 text-center border-b pb-2">➕ افزودن رویداد جدید</h2>
    <form method="post" enctype="multipart/form-data" class="space-y-6">
        <div>
            <label class="block mb-1 text-right font-medium text-gray-700">عنوان رویداد</label>
            <input name="title" required class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500" type="text">
        </div>

        <div>
            <label class="block mb-1 text-right font-medium text-gray-700">توضیحات</label>
            <textarea name="description" rows="4" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"></textarea>
        </div>

        <div>
            <label class="block mb-1 text-right font-medium text-gray-700">تصویر رویداد (اختیاری)</label>
            <input type="file" name="image" class="w-full border border-gray-300 rounded-lg px-4 py-2">
        </div>

        <div>
            <button type="submit" class="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-6 rounded-lg transition duration-200">
                📥 ثبت رویداد
            </button>
        </div>
    </form>
</div>

<?php include("footer.php"); ?>
