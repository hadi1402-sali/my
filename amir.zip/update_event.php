<?php
include("header.php");
include("connec.php");
mysqli_set_charset($connect, "utf8mb4");

// چک کردن ارسالی بودن فرم
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = intval($_POST['id']);
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $image_url = trim($_POST['image_url']);

    $query = "UPDATE events SET title = ?, description = ?, image_url = ? WHERE id = ?";
    $stmt = mysqli_prepare($connect, $query);
    if (!$stmt) {
        die("<div class='text-red-600 font-bold my-4'>خطا در آماده‌سازی کوئری: " . mysqli_error($connect) . "</div>");
    }

    mysqli_stmt_bind_param($stmt, "sssi", $title, $description, $image_url, $id);

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success'] = "✅ رویداد با موفقیت ویرایش شد.";
        header("Location: login_action.php"); // اگر مسیر مقصد عوض شد، اینجا اصلاح کن
        exit;
    } else {
        echo "<div class='text-red-600 font-bold my-4'>خطا در ویرایش رویداد: " . mysqli_stmt_error($stmt) . "</div>";
    }
} else {
    header("Location: login_action.php"); // مسیر مقصد را در صورت نیاز تغییر بده
}

include("footer.php");
?>
